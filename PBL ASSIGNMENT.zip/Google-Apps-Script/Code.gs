/*************************************************
 * Code.gs
 * Sensor Data Configuration and Cleaning
 *************************************************/

var CONFIG = {
  DATA_SHEET: 'Sheet1',
  BACKUP_SHEET: 'Raw Backup',
  FORECAST_SHEET: 'Forecasts',
  HISTORY_SHEET: 'Forecast History',

  // Sensor validation limits
  MIN_TEMP: 10,
  MAX_TEMP: 50,
  MIN_HUM: 1,
  MAX_HUM: 100,

  // Forecast configuration
  HOUR: 3600000,
  WINDOW_HOURS: 24,
  MIN_HOURS: 6,
  FORECAST_HOURS: 24,
  SHOW_HOURS: 48,

  // Maximum age of latest reading
  MAX_STALE_HOURS: 2,
  ALLOW_STALE_DATA: true,

  DATE_FORMAT: 'yyyy-MM-dd HH:mm:ss'
};


/*************************************************
 * CUSTOM MENU
 *************************************************/

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Sensor Data')
    .addItem('Clean Data', 'cleanData')
    .addItem('Run Forecast', 'runForecast')
    .addSeparator()
    .addItem('Enable Hourly Forecast', 'createHourlyTrigger')
    .addItem('Disable Hourly Forecast', 'removeHourlyTrigger')
    .addToUi();
}


/*************************************************
 * VALIDATE SENSOR READINGS
 *************************************************/

function validateReading(row) {

  if (!row || row.length < 3) {
    return null;
  }

  // Reject blank timestamps
  if (
    row[0] === '' ||
    row[0] === null ||
    row[0] === undefined
  ) {
    return null;
  }

  // Reject blank or non-numeric sensor cells
  for (var i = 1; i <= 2; i++) {

    if (
      row[i] === null ||
      row[i] === undefined ||
      typeof row[i] === 'boolean' ||
      (
        typeof row[i] === 'string' &&
        row[i].trim() === ''
      )
    ) {
      return null;
    }
  }

  var timestamp = row[0] instanceof Date
    ? new Date(row[0].getTime())
    : new Date(row[0]);

  var temp = Number(row[1]);
  var hum = Number(row[2]);

  if (!isFinite(timestamp.getTime())) {
    return null;
  }

  // Reject future timestamps
  if (timestamp.getTime() > Date.now()) {
    return null;
  }

  if (!isFinite(temp) || !isFinite(hum)) {
    return null;
  }

  if (
    temp < CONFIG.MIN_TEMP ||
    temp > CONFIG.MAX_TEMP
  ) {
    return null;
  }

  if (
    hum < CONFIG.MIN_HUM ||
    hum > CONFIG.MAX_HUM
  ) {
    return null;
  }

  return [timestamp, temp, hum];
}


/*************************************************
 * CLEAN SENSOR DATA
 *************************************************/

function cleanData() {

  var lock = LockService.getScriptLock();
  var result;

  if (!lock.tryLock(30000)) {
    message('Another operation is running. Try again later.');
    return;
  }

  try {

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(CONFIG.DATA_SHEET);

    if (!sheet) {
      throw new Error('Sheet1 was not found.');
    }

    var lastRow = sheet.getLastRow();

    if (lastRow < 2) {
      throw new Error('No sensor data available.');
    }

    var rows = sheet
      .getRange(2, 1, lastRow - 1, 3)
      .getValues();

    var cleaned = [];
    var seen = {};
    var invalidCount = 0;
    var duplicateCount = 0;

    rows.forEach(function(row) {

      var valid = validateReading(row);

      if (!valid) {
        invalidCount++;
        return;
      }

      // Remove exact duplicate readings
      var key =
        valid[0].getTime() + '|' +
        valid[1] + '|' +
        valid[2];

      if (seen[key]) {
        duplicateCount++;
        return;
      }

      seen[key] = true;
      cleaned.push(valid);

    });

    // Never erase the original data if everything fails
    if (cleaned.length === 0) {
      throw new Error(
        'No valid readings found. Original data preserved.'
      );
    }

    cleaned.sort(function(a, b) {
      return a[0].getTime() - b[0].getTime();
    });

    // Refresh backup before changing original data
    var backup = ss.getSheetByName(CONFIG.BACKUP_SHEET);

    if (!backup) {
      backup = ss.insertSheet(CONFIG.BACKUP_SHEET);
    }

    var sourceRange = sheet.getDataRange();

    ensureSheetSize(
      backup,
      sourceRange.getNumRows(),
      sourceRange.getNumColumns()
    );

    backup.clearContents();

    sourceRange.copyTo(
      backup.getRange(
        1,
        1,
        sourceRange.getNumRows(),
        sourceRange.getNumColumns()
      ),
      SpreadsheetApp.CopyPasteType.PASTE_VALUES,
      false
    );

    if (lastRow > 1) {
      backup
        .getRange(2, 1, lastRow - 1, 1)
        .setNumberFormat(CONFIG.DATE_FORMAT);
    }

    SpreadsheetApp.flush();

    // Write valid readings first
    sheet.getRange(2, 1, cleaned.length, 3)
      .setValues(cleaned);

    // Remove remaining invalid or duplicate rows
    var remaining = rows.length - cleaned.length;

    if (remaining > 0) {
      sheet
        .getRange(cleaned.length + 2, 1, remaining, 3)
        .clearContent();
    }

    sheet.getRange(2, 1, cleaned.length, 1)
      .setNumberFormat(CONFIG.DATE_FORMAT);

    sheet.getRange(2, 2, cleaned.length, 2)
      .setNumberFormat('0.00');

    result =
      'Data cleaning completed.\n\n' +
      'Original readings: ' + rows.length + '\n' +
      'Valid readings: ' + cleaned.length + '\n' +
      'Invalid readings removed: ' + invalidCount + '\n' +
      'Duplicates removed: ' + duplicateCount + '\n\n' +
      'Backup saved in Raw Backup.';

  } catch (error) {

    result = 'Cleaning failed: ' + error.message;
    Logger.log(result);

  } finally {

    lock.releaseLock();

  }

  message(result);
}


/*************************************************
 * ENSURE SHEET HAS ENOUGH SPACE
 *************************************************/

function ensureSheetSize(sheet, rows, columns) {

  if (sheet.getMaxRows() < rows) {
    sheet.insertRowsAfter(
      sheet.getMaxRows(),
      rows - sheet.getMaxRows()
    );
  }

  if (sheet.getMaxColumns() < columns) {
    sheet.insertColumnsAfter(
      sheet.getMaxColumns(),
      columns - sheet.getMaxColumns()
    );
  }
}


/*************************************************
 * DISPLAY MESSAGE
 *************************************************/

function message(text) {

  Logger.log(text);

  try {

    SpreadsheetApp.getActiveSpreadsheet()
      .toast(text, 'Sensor Data', 8);

  } catch (error) {

    Logger.log(text);

  }
}
