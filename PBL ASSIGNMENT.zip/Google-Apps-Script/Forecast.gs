/*************************************************
 * Forecast.gs
 *
 * Forecasting Method:
 * Linear Regression (Least Squares)
 *
 * Forecast Horizon: 24 Hours
 * Training Window: Latest 24 Hours
 * Prediction Interval: Nominal 95%
 * Accuracy Metric: Mean Absolute Error (MAE)
 *************************************************/


/*************************************************
 * CONVERT RAW READINGS INTO HOURLY AVERAGES
 *************************************************/

function makeHourly(rows) {

  var buckets = {};
  var seen = {};
  var validCount = 0;

  rows.forEach(function(row) {

    var valid = validateReading(row);

    if (!valid) {
      return;
    }

    var key =
      valid[0].getTime() + '|' +
      valid[1] + '|' +
      valid[2];

    if (seen[key]) {
      return;
    }

    seen[key] = true;

    var hour = Math.floor(
      valid[0].getTime() / CONFIG.HOUR
    ) * CONFIG.HOUR;

    if (!buckets[hour]) {

      buckets[hour] = {
        tempSum: 0,
        humSum: 0,
        count: 0
      };

    }

    buckets[hour].tempSum += valid[1];
    buckets[hour].humSum += valid[2];
    buckets[hour].count++;

    validCount++;

  });

  var times = Object.keys(buckets)
    .map(Number)
    .sort(function(a, b) {
      return a - b;
    });

  var observations = times.map(function(time) {

    var bucket = buckets[time];

    return {
      time: time,
      temp: bucket.tempSum / bucket.count,
      hum: bucket.humSum / bucket.count,
      count: bucket.count
    };

  });

  return {
    observations: observations,
    validCount: validCount
  };
}


/*************************************************
 * LEAST SQUARES LINEAR REGRESSION
 *
 * Equation:
 * y = intercept + slope * x
 *************************************************/

function linearFit(x, y) {

  var n = x.length;

  if (n !== y.length || n < 3) {
    throw new Error('Insufficient regression data.');
  }

  var sumX = 0;
  var sumY = 0;

  for (var i = 0; i < n; i++) {
    sumX += x[i];
    sumY += y[i];
  }

  var xbar = sumX / n;
  var ybar = sumY / n;

  var sxx = 0;
  var sxy = 0;
  var sst = 0;

  for (var j = 0; j < n; j++) {

    var dx = x[j] - xbar;
    var dy = y[j] - ybar;

    sxx += dx * dx;
    sxy += dx * dy;
    sst += dy * dy;

  }

  if (sxx <= 0) {
    throw new Error('Invalid regression time values.');
  }

  var slope = sxy / sxx;
  var intercept = ybar - slope * xbar;

  var sse = 0;
  var absoluteError = 0;

  for (var k = 0; k < n; k++) {

    var predicted = intercept + slope * x[k];
    var error = y[k] - predicted;

    sse += error * error;
    absoluteError += Math.abs(error);

  }

  // R-squared is undefined for constant observations
  var r2 = sst > 0
    ? 1 - sse / sst
    : null;

  var residualError = Math.sqrt(
    sse / (n - 2)
  );

  return {
    n: n,
    slope: slope,
    intercept: intercept,
    xbar: xbar,
    sxx: sxx,
    r2: r2,
    s: residualError,
    mae: absoluteError / n
  };
}


/*************************************************
 * STUDENT'S T CRITICAL VALUES
 * Two-tailed 95% prediction interval
 *************************************************/

function tValue(df) {

  var values = [
    null,
    12.706, 4.303, 3.182, 2.776, 2.571,
    2.447, 2.365, 2.306, 2.262, 2.228,
    2.201, 2.179, 2.160, 2.145, 2.131,
    2.120, 2.110, 2.101, 2.093, 2.086,
    2.080, 2.074, 2.069, 2.064, 2.060,
    2.056, 2.052, 2.048, 2.045, 2.042
  ];

  if (df < 1) {
    throw new Error('Invalid degrees of freedom.');
  }

  if (df <= 30) {
    return values[df];
  }

  // Approximation for larger sample sizes
  var z = 1.95996398454;

  return z +
    (Math.pow(z, 3) + z) / (4 * df) +
    (
      5 * Math.pow(z, 5) +
      16 * Math.pow(z, 3) +
      3 * z
    ) / (96 * df * df);
}


/*************************************************
 * LINEAR FORECAST AND PREDICTION INTERVAL
 *************************************************/

function linearForecast(fit, x0) {

  var predicted =
    fit.intercept + fit.slope * x0;

  var distance = x0 - fit.xbar;

  var standardError = fit.s * Math.sqrt(
    1 +
    1 / fit.n +
    (distance * distance) / fit.sxx
  );

  var margin =
    tValue(fit.n - 2) * standardError;

  return {
    value: predicted,
    upper: predicted + margin,
    lower: predicted - margin
  };
}


/*************************************************
 * LIMIT OUTPUT TO CONFIGURED SENSOR RANGE
 *************************************************/

function clamp(value, min, max) {

  return Math.max(
    min,
    Math.min(max, value)
  );
}


function limitForecast(forecast, min, max) {

  return {
    value: clamp(forecast.value, min, max),
    upper: clamp(forecast.upper, min, max),
    lower: clamp(forecast.lower, min, max)
  };
}


/*************************************************
 * SAVE FORECAST HISTORY
 *
 * Only the final forecast horizon is saved.
 * Default: exactly 24 hours ahead.
 *************************************************/

function saveHistory(ss, baseMs, targetMs, temp, hum) {

  var sheet = ss.getSheetByName(
    CONFIG.HISTORY_SHEET
  );

  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.HISTORY_SHEET);
  }

  var headers = [
    'Base Hour',
    'Target Hour',
    'Forecast Temperature (°C)',
    'Forecast Humidity (%)'
  ];

  if (sheet.getLastRow() === 0) {

    sheet.getRange(1, 1, 1, headers.length)
      .setValues([headers]);

    sheet.setFrozenRows(1);

  }

  var expectedHorizon =
    CONFIG.FORECAST_HOURS * CONFIG.HOUR;

  if (targetMs - baseMs !== expectedHorizon) {
    throw new Error('Invalid forecast history horizon.');
  }

  var lastRow = sheet.getLastRow();

  if (lastRow > 1) {

    var existing = sheet
      .getRange(2, 1, lastRow - 1, 1)
      .getValues();

    // Check all historical base hours
    for (var i = 0; i < existing.length; i++) {

      var previous = parseTime(existing[i][0]);

      if (previous === baseMs) {
        return sheet;
      }

    }
  }

  sheet.appendRow([
    new Date(baseMs),
    new Date(targetMs),
    round(temp, 4),
    round(hum, 4)
  ]);

  var newRow = sheet.getLastRow();

  sheet.getRange(newRow, 1, 1, 2)
    .setNumberFormat(CONFIG.DATE_FORMAT);

  sheet.getRange(newRow, 3, 1, 2)
    .setNumberFormat('0.00');

  return sheet;
}


/*************************************************
 * PARSE HISTORICAL TIMESTAMP
 *************************************************/

function parseTime(value) {

  if (
    value === '' ||
    value === null ||
    value === undefined
  ) {
    return NaN;
  }

  return value instanceof Date
    ? value.getTime()
    : new Date(value).getTime();
}


/*************************************************
 * EVALUATE FORECAST ACCURACY
 *
 * MAE = Average absolute prediction error
 *************************************************/

function checkAccuracy(sheet, hourly) {

  var result = {
    tempMAE: null,
    humMAE: null,
    count: 0
  };

  if (!sheet || sheet.getLastRow() < 2) {
    return result;
  }

  var actual = {};

  // Only evaluate completed hourly observations
  var currentHour = Math.floor(
    Date.now() / CONFIG.HOUR
  ) * CONFIG.HOUR;

  hourly.observations.forEach(function(item) {

    if (item.time < currentHour) {
      actual[item.time] = item;
    }

  });

  var rows = sheet
    .getRange(2, 1, sheet.getLastRow() - 1, 4)
    .getValues();

  var tempError = 0;
  var humError = 0;
  var seen = {};

  var expectedHorizon =
    CONFIG.FORECAST_HOURS * CONFIG.HOUR;

  rows.forEach(function(row) {

    var base = parseTime(row[0]);
    var target = parseTime(row[1]);

    if (!isFinite(base) || !isFinite(target)) {
      return;
    }

    if (target - base !== expectedHorizon) {
      return;
    }

    if (!actual[target]) {
      return;
    }

    if (
      row[2] === '' ||
      row[3] === '' ||
      row[2] === null ||
      row[3] === null
    ) {
      return;
    }

    var predictedTemp = Number(row[2]);
    var predictedHum = Number(row[3]);

    if (
      !isFinite(predictedTemp) ||
      !isFinite(predictedHum)
    ) {
      return;
    }

    if (
      predictedTemp < CONFIG.MIN_TEMP ||
      predictedTemp > CONFIG.MAX_TEMP ||
      predictedHum < CONFIG.MIN_HUM ||
      predictedHum > CONFIG.MAX_HUM
    ) {
      return;
    }

    var key = base + '|' + target;

    if (seen[key]) {
      return;
    }

    seen[key] = true;

    tempError += Math.abs(
      actual[target].temp - predictedTemp
    );

    humError += Math.abs(
      actual[target].hum - predictedHum
    );

    result.count++;

  });

  if (result.count > 0) {

    result.tempMAE = tempError / result.count;
    result.humMAE = humError / result.count;

  }

  return result;
}


/*************************************************
 * MAIN FORECAST FUNCTION
 *************************************************/

function runForecast() {

  var lock = LockService.getScriptLock();
  var result;

  if (!lock.tryLock(30000)) {

    message('Another operation is running.');
    return;

  }

  try {

    var ss = SpreadsheetApp.getActiveSpreadsheet();

    var source = ss.getSheetByName(
      CONFIG.DATA_SHEET
    );

    if (!source) {
      throw new Error('Sheet1 was not found.');
    }

    if (source.getLastRow() < 2) {
      throw new Error('No sensor readings available.');
    }

    var rows = source
      .getRange(2, 1, source.getLastRow() - 1, 3)
      .getValues();

    var hourly = makeHourly(rows);

    var observations = hourly.observations;

    if (observations.length === 0) {
      throw new Error('No valid sensor readings.');
    }

    var currentHour = Math.floor(
      Date.now() / CONFIG.HOUR
    ) * CONFIG.HOUR;

    // Exclude the current incomplete hour
    var completed = observations.filter(
      function(item) {
        return item.time < currentHour;
      }
    );

    if (completed.length === 0) {
      throw new Error('No completed hourly readings.');
    }

    var latest = completed[completed.length - 1];

    var baseMs = latest.time;

    // Detect stale sensor data
    var ageHours =
      (Date.now() - (baseMs + CONFIG.HOUR)) /
      CONFIG.HOUR;

    if (ageHours > CONFIG.MAX_STALE_HOURS) {

      var warning =
        'Sensor data is stale. Latest completed hour: ' +
        Utilities.formatDate(
          new Date(baseMs),
          ss.getSpreadsheetTimeZone(),
          CONFIG.DATE_FORMAT
        );

      if (!CONFIG.ALLOW_STALE_DATA) {
        throw new Error(warning);
      }

      Logger.log(warning + ' — Historical forecasting enabled.');

    }

    // Latest 24-hour training window
    var windowStart = baseMs -
      (CONFIG.WINDOW_HOURS - 1) * CONFIG.HOUR;

    var training = completed.filter(function(item) {

      return item.time >= windowStart &&
             item.time <= baseMs;

    });

    if (training.length < CONFIG.MIN_HOURS) {

      throw new Error(
        'At least ' + CONFIG.MIN_HOURS +
        ' valid hourly observations are required. ' +
        'Available: ' + training.length
      );

    }

    // Preserve real time gaps between observations
    var x = training.map(function(item) {

      return (item.time - windowStart) /
        CONFIG.HOUR;

    });

    var temp = training.map(function(item) {
      return item.temp;
    });

    var hum = training.map(function(item) {
      return item.hum;
    });

    // Fit Least Squares regression models
    var fitT = linearFit(x, temp);
    var fitH = linearFit(x, hum);

    var forecasts = [];

    var baseX =
      (baseMs - windowStart) / CONFIG.HOUR;

    // Generate next 24 hourly predictions
    for (
      var k = 1;
      k <= CONFIG.FORECAST_HOURS;
      k++
    ) {

      var x0 = baseX + k;

      var forecastT = limitForecast(
        linearForecast(fitT, x0),
        CONFIG.MIN_TEMP,
        CONFIG.MAX_TEMP
      );

      var forecastH = limitForecast(
        linearForecast(fitH, x0),
        CONFIG.MIN_HUM,
        CONFIG.MAX_HUM
      );

      forecasts.push({

        time: baseMs + k * CONFIG.HOUR,
        temp: forecastT,
        hum: forecastH

      });

    }

    var finalForecast =
      forecasts[forecasts.length - 1];

    // Save final-horizon forecast
    var history = saveHistory(
      ss,
      baseMs,
      finalForecast.time,
      finalForecast.temp.value,
      finalForecast.hum.value
    );

    var accuracy = checkAccuracy(history, hourly);

    // Generate Looker Studio output
    writeForecastSheet(
      ss,
      hourly,
      baseMs,
      forecasts,
      fitT,
      fitH,
      accuracy,
      training.length
    );

    result =
      'Forecast completed.\n' +
      'Training observations: ' + training.length + '\n' +
      'Forecast horizon: ' + CONFIG.FORECAST_HOURS +
      ' hours.';

  } catch (error) {

    result = 'Forecast failed: ' + error.message;

    Logger.log(result);

    try {

      var active = SpreadsheetApp.getActiveSpreadsheet();

      var output = active.getSheetByName(
        CONFIG.FORECAST_SHEET
      );

      if (output) {

        ensureSheetSize(output, 13, 12);

        output.getRange('K12:L12').setValues([
          ['Data Status', result]
        ]);

      }

    } catch (statusError) {

      Logger.log(statusError.message);

    }

  } finally {

    lock.releaseLock();

  }

  message(result);
}


/*************************************************
 * WRITE FORECAST OUTPUT
 *************************************************/

function writeForecastSheet(
  ss,
  hourly,
  baseMs,
  forecasts,
  fitT,
  fitH,
  accuracy,
  trainingCount
) {

  var sheet = ss.getSheetByName(
    CONFIG.FORECAST_SHEET
  );

  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.FORECAST_SHEET);
  }

  var headers = [

    'Timestamp',
    'Temperature (°C)',
    'Humidity (%)',
    'Forecast Temperature (°C)',
    'Temperature Upper Bound',
    'Temperature Lower Bound',
    'Forecast Humidity (%)',
    'Humidity Upper Bound',
    'Humidity Lower Bound'

  ];

  var output = [headers];

  var actual = {};

  hourly.observations.forEach(function(item) {

    actual[item.time] = item;

  });

  var displayStart = baseMs -
    (CONFIG.SHOW_HOURS - 1) * CONFIG.HOUR;

  // Historical hourly readings
  for (
    var time = displayStart;
    time <= baseMs;
    time += CONFIG.HOUR
  ) {

    var item = actual[time];

    output.push([

      new Date(time),

      item ? round(item.temp, 4) : '',
      item ? round(item.hum, 4) : '',

      '', '', '', '', '', ''

    ]);

  }

  // Forecast readings
  forecasts.forEach(function(item) {

    output.push([

      new Date(item.time),

      '',

      '',

      round(item.temp.value, 4),
      round(item.temp.upper, 4),
      round(item.temp.lower, 4),

      round(item.hum.value, 4),
      round(item.hum.upper, 4),
      round(item.hum.lower, 4)

    ]);

  });

  ensureSheetSize(
    sheet,
    Math.max(output.length, 20),
    12
  );

  // Preserve sheet identity and Looker Studio connection
  var oldLastRow = sheet.getLastRow();

  sheet.getRange(1, 1, output.length, 9)
    .setValues(output);

  // Remove obsolete output rows
  if (oldLastRow > output.length) {

    sheet.getRange(
      output.length + 1,
      1,
      oldLastRow - output.length,
      9
    ).clearContent();

  }

  sheet.getRange(2, 1, output.length - 1, 1)
    .setNumberFormat(CONFIG.DATE_FORMAT);

  sheet.getRange(2, 2, output.length - 1, 8)
    .setNumberFormat('0.00');

  sheet.getRange(1, 1, 1, 9)
    .setFontWeight('bold')
    .setBackground('#d9ead3');

  sheet.setFrozenRows(1);

  var missingHours =
    CONFIG.WINDOW_HOURS - trainingCount;

  var ageHours =
  (Date.now() - (baseMs + CONFIG.HOUR)) /
  CONFIG.HOUR;

  var status = missingHours === 0
    ? 'OK - Complete training window'
    : 'OK - ' + missingHours +
      ' missing hourly observations';

  if (ageHours > CONFIG.MAX_STALE_HOURS) {
    status = 'Historical Forecast - ' + status;
  }
  
  var summary = [

    ['Method', 'Linear Regression (Least Squares)'],

    ['Actual Hours Used', trainingCount],

    ['Forecast Horizon (Hours)', CONFIG.FORECAST_HOURS],

    ['Temperature Slope (°C/hour)', round(fitT.slope, 4)],

    ['Humidity Slope (%/hour)', round(fitH.slope, 4)],

    ['Temperature R²', metric(fitT.r2, 4)],

    ['Humidity R²', metric(fitH.r2, 4)],

    ['Fit MAE (Temp / Hum)', 
      round(fitT.mae, 4) + ' / ' + round(fitH.mae, 4)],

    ['Forecast MAE Temperature (°C)',
      metric(accuracy.tempMAE, 4)],

    ['Forecast MAE Humidity (%)',
      metric(accuracy.humMAE, 4)],

    ['Last Completed Hour', new Date(baseMs)],

    ['Data Status', status],

    ['Last Updated', new Date()],

    ['Evaluated Forecasts', accuracy.count],

    ['Training Window (Hours)', CONFIG.WINDOW_HOURS],

    ['Missing Training Hours', missingHours],

    ['Valid Raw Readings', hourly.validCount],

    ['Prediction Bounds',
      'Nominal 95% - clipped to sensor limits']

  ];

  sheet.getRange('K1:L20').clearContent();

  sheet.getRange(1, 11, summary.length, 2)
    .setValues(summary);

  sheet.getRange('K1:K18')
    .setFontWeight('bold');

  sheet.getRange('L11')
    .setNumberFormat(CONFIG.DATE_FORMAT);

  sheet.getRange('L13')
    .setNumberFormat(CONFIG.DATE_FORMAT);

  sheet.autoResizeColumns(1, 12);

}


/*************************************************
 * ROUND NUMERIC VALUES
 *************************************************/

function round(value, decimals) {

  var factor = Math.pow(10, decimals);

  return Math.round(value * factor) / factor;
}


/*************************************************
 * FORMAT UNAVAILABLE METRICS
 *************************************************/

function metric(value, decimals) {

  if (
    value === null ||
    value === undefined ||
    !isFinite(value)
  ) {
    return 'N/A';
  }

  return round(value, decimals);
}


/*************************************************
 * CREATE AUTOMATIC HOURLY TRIGGER
 *************************************************/

function createHourlyTrigger() {

  deleteForecastTriggers();

  ScriptApp.newTrigger('runForecast')
    .timeBased()
    .everyHours(1)
    .create();

  message('Automatic hourly forecasting enabled.');
}


/*************************************************
 * REMOVE AUTOMATIC HOURLY TRIGGER
 *************************************************/

function removeHourlyTrigger() {

  deleteForecastTriggers();

  message('Automatic hourly forecasting disabled.');
}


function deleteForecastTriggers() {

  var triggers = ScriptApp.getProjectTriggers();

  triggers.forEach(function(trigger) {

    if (
      trigger.getHandlerFunction() === 'runForecast'
    ) {

      ScriptApp.deleteTrigger(trigger);

    }

  });
}
